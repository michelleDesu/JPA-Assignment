package se.lexicon.michelle.JPAAssignment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaAssignmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
